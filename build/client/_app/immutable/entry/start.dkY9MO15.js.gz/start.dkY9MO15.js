import{a as t}from"../chunks/entry.87YOewAd.js";export{t as start};
